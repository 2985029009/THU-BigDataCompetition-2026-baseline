import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

SRC_DIR = Path(__file__).resolve().parents[1] / "code" / "src"
sys.path.insert(0, str(SRC_DIR))

try:
    import torch
    from torch.utils.data import DataLoader

    from predict import get_predict_candidate_ids  # noqa: E402
    from train import RankingDataset, collate_fn, evaluate_ranking_model  # noqa: E402
    from utils import returns_to_relevance  # noqa: E402
except ModuleNotFoundError as exc:
    if exc.name != "torch":
        raise
    torch = None


if torch is not None:
    class _ScoreFromFeature(torch.nn.Module):
        def forward(self, src, stock_padding_mask=None):
            return src[:, :, -1, 0]


    class _NoopCriterion:
        def __call__(self, predictions, relevance):
            return predictions.sum() * 0.0


@unittest.skipUnless(torch is not None, "requires the project PyTorch runtime")
class PredictStyleEvaluationTests(unittest.TestCase):
    def test_candidate_universe_matches_predict_rules(self):
        day = pd.Timestamp("2026-03-02")
        frame = pd.DataFrame(
            {
                "股票代码": ["000003", "000001", "000004", "000002"],
                "日期": [day] * 4,
                "is_member": [True, True, False, True],
                "is_tradable": [True, True, True, False],
            }
        )
        self.assertEqual(
            get_predict_candidate_ids(frame, day), ["000001", "000003"]
        )

    def test_full_ranking_export_uses_all_scored_stocks_before_top5(self):
        sequences = [
            np.asarray([[[0.2]], [[0.9]], [[0.5]]], dtype=np.float32)
        ]
        targets = [np.asarray([0.01, 0.03, -0.01], dtype=np.float32)]
        dataset = RankingDataset(
            sequences,
            targets,
            [returns_to_relevance(targets[0])],
            [[0, 1, 2]],
        )
        loader = DataLoader(dataset, batch_size=1, shuffle=False, collate_fn=collate_fn)
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "full_ranking.csv"
            _, metrics = evaluate_ranking_model(
                _ScoreFromFeature(),
                loader,
                _NoopCriterion(),
                torch.device("cpu"),
                None,
                0,
                full_ranking_output=str(output),
                sample_dates=[pd.Timestamp("2026-03-02")],
                stockid2idx={"000001": 0, "000002": 1, "000003": 2},
            )
            exported = pd.read_csv(output, dtype={"stock_id": str})

        self.assertEqual(metrics["_n_days"], 1)
        self.assertEqual(len(exported), 3)
        self.assertEqual(exported["stock_id"].tolist(), ["000002", "000003", "000001"])
        self.assertEqual(exported["raw_rank"].tolist(), [1, 2, 3])
        self.assertTrue(exported["selected_top5"].all())


if __name__ == "__main__":
    unittest.main()
