# Seed-42 V100 消融实验冻结计划

## 计算环境

- 单卡 Tesla V100-SXM2-32GB，驱动 550.163.01。
- Python 3.11.8，PyTorch 2.2.1+cu121。
- 工作目录固定为 `/hy-tmp/codex/ablation_study_seed42_v100_20260909`。
- 只训练 seed 42，不执行多随机种子、bootstrap、显著性或稳定性检验。
- `stability_weight=0.05` 是主模型原有损失项，保持不变。

## 六个配置

| ID | 唯一差异 | 比较 |
|---|---|---|
| C0 | hybrid + self_attention + head-focused + gate off | 无门控主干参考 |
| C1 | C0基础上 gate on | C1 - C0：门控贡献 |
| C2 | tcn_only，其余同C0 | C0 - C2：iTransformer分支贡献 |
| C3 | itransformer_only，其余同C0 | C0 - C3：TCN分支贡献 |
| C4 | stockwise_ffn替代self_attention | C0 - C4：跨股票通信贡献 |
| C5 | head=0、global=1.0，其余同C0 | C0 - C5：Top-5定向损失贡献 |

共同设置：28维特征、60日序列、自然采样、50轮、学习率1e-5、`stability_weight=0.05`、验证集Top-5 return选模、train+validation重新训练、完整候选池测试评估。

## 执行和完成边界

- 六配置乘五个冻结窗口，共30个run，V100单卡串行。
- 不复用本地历史run作为正式结果；所有六配置在同一远端环境重跑。
- 一个run只有在完整候选池、连续raw rank、预期测试日数和全部审计文件通过后才标记为completed。
- 任一失败先停止队列，保留失败现场；修复后只重跑失败或未开始项，不覆盖已有证据。
- 每15分钟检查GPU、显存、进程、epoch、NaN和磁盘；结果仅作seed-42消融描述，不作跨初始化稳定性结论。
