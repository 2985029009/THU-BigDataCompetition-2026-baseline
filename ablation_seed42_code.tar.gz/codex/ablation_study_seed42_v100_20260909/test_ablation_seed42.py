import copy
import importlib.util
import subprocess
import sys
import unittest
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SRC = ROOT / "code" / "src"
sys.path.insert(0, str(SRC))

from config import config  # noqa: E402
from model import CrossStockAttention, INFO_TCN_iTransformer, StockwiseFeedForward  # noqa: E402
from train import HeadFocusedRankingLoss  # noqa: E402


def load_runner():
    path = HERE / "run_ablation_seed42.py"
    spec = importlib.util.spec_from_file_location("ablation_seed42", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


class Seed42AblationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runner = load_runner()

    def test_matrix_is_exactly_six_seed42_configs(self):
        self.assertEqual(list(self.runner.CONFIGURATIONS), ["C0", "C1", "C2", "C3", "C4", "C5"])
        self.assertEqual(self.runner.SEED, 42)
        self.assertEqual(
            {cfg["soft_gate"] for cfg in self.runner.CONFIGURATIONS.values()},
            {"on", "off"},
        )

    def test_cross_stock_control_matches_parameter_budget(self):
        attention = CrossStockAttention(256, nhead=4, dropout=0.1)
        control = StockwiseFeedForward(256, dropout=0.1)
        attention_count = sum(parameter.numel() for parameter in attention.parameters())
        control_count = sum(parameter.numel() for parameter in control.parameters())
        self.assertLess(abs(attention_count - control_count) / attention_count, 0.05)

    def test_loss_control_keeps_stability_and_disables_head(self):
        cfg = copy.deepcopy(config)
        cfg.update({"head_loss_weight": 0.0, "global_rank_weight": 1.0, "stability_weight": 0.05})
        criterion = HeadFocusedRankingLoss(cfg)
        self.assertEqual(criterion.head_weight, 0.0)
        self.assertEqual(criterion.global_weight, 1.0)
        self.assertEqual(criterion.stability_weight, 0.05)

    def test_all_configs_seeded_cuda_forward_backward(self):
        import torch

        self.assertTrue(torch.cuda.is_available())
        device = torch.device("cuda:0")
        features = list(config["include_features"])
        source = torch.randn(1, 8, 60, len(features), device=device)
        target = torch.randn(1, 8, device=device)
        for config_id, ablation in self.runner.CONFIGURATIONS.items():
            torch.manual_seed(42)
            torch.cuda.manual_seed_all(42)
            cfg = copy.deepcopy(config)
            cfg.update({
                "feature_names": features,
                "model_variant": ablation["model_variant"],
                "cross_stock_mode": ablation["cross_stock_mode"],
                "soft_gate_enabled": ablation["soft_gate"] == "on",
                "head_loss_weight": ablation["head_loss_weight"],
                "global_rank_weight": ablation["global_rank_weight"],
                "stability_weight": 0.05,
            })
            model = INFO_TCN_iTransformer(len(features), cfg, num_stocks=8).to(device)
            criterion = HeadFocusedRankingLoss(cfg)
            output = model(source)
            loss = criterion(output, target)
            loss.backward()
            self.assertTrue(torch.isfinite(loss), config_id)
            del model, criterion, output, loss
            torch.cuda.empty_cache()

    def test_negative_head_weight_is_rejected_before_training(self):
        process = subprocess.run(
            [sys.executable, str(SRC / "train.py"), "--head-loss-weight", "-0.1"],
            cwd=str(SRC),
            capture_output=True,
            text=True,
        )
        self.assertNotEqual(process.returncode, 0)
        self.assertIn("head-loss-weight", process.stdout + process.stderr)


if __name__ == "__main__":
    unittest.main()
