# Gpushare V100 seed-42 ablation runbook

Remote project root: `/hy-tmp/codex/ablation_study_seed42_v100_20260909/project`

```bash
cd /hy-tmp/codex/ablation_study_seed42_v100_20260909
sha256sum -c package.sha256
mkdir -p project
tar -xzf ablation_seed42_package.tar.gz -C project
mkdir -p python-packages
python3 -m pip install --target python-packages -r project/codex/ablation_study_seed42_v100_20260909/requirements-nontorch.txt
PYTHONPATH=/hy-tmp/codex/ablation_study_seed42_v100_20260909/python-packages python3 project/codex/ablation_study_seed42_v100_20260909/test_ablation_seed42.py
PYTHONPATH=/hy-tmp/codex/ablation_study_seed42_v100_20260909/python-packages python3 project/codex/ablation_study_seed42_v100_20260909/run_ablation_seed42.py --output-root /hy-tmp/codex/ablation_study_seed42_v100_20260909/runs/batch_seed42_v100
```

The final command is a dry run. It must print exactly 30 commands and must not create the output directory. Formal execution adds `--execute`; recovery adds both `--execute --resume`.

Launch the formal serial queue only after the CUDA witness and dry run pass:

```bash
cd /hy-tmp/codex/ablation_study_seed42_v100_20260909/project
screen -dmS ablation_seed42_v100 bash -lc 'PYTHONPATH=/hy-tmp/codex/ablation_study_seed42_v100_20260909/python-packages python3 codex/ablation_study_seed42_v100_20260909/run_ablation_seed42.py --output-root /hy-tmp/codex/ablation_study_seed42_v100_20260909/runs/batch_seed42_v100 --execute 2>&1 | tee /hy-tmp/codex/ablation_study_seed42_v100_20260909/queue.log'
```
