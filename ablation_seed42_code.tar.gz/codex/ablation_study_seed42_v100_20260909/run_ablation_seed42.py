"""Run the frozen six-configuration, five-window, seed-42 ablation suite."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import subprocess
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TRAIN_SCRIPT = ROOT / "code" / "src" / "train.py"
MODEL_SCRIPT = ROOT / "code" / "src" / "model.py"
CONFIG_SCRIPT = ROOT / "code" / "src" / "config.py"
PREDICT_SCRIPT = ROOT / "code" / "src" / "predict.py"
SCORER = ROOT / "test" / "score_self.py"
PROTOCOL_PATH = (
    ROOT
    / "codex_generated"
    / "plans"
    / "monthly_walk_forward_202603_202607_week_owned_labelhorizon_repaired_20260809.json"
)
DATA_PATH = (
    ROOT
    / "codex_generated"
    / "datasets"
    / "tushare_hs300_continuous_20230724_20260731_labelhorizon_repaired_20260809"
    / "model_data.csv"
)
BASE_RUNNER = (
    ROOT
    / "codex_generated"
    / "scripts"
    / "experiments"
    / "run_monthly_walk_forward_202603_202607.py"
)
DEFAULT_OUTPUT = HERE / "runs" / "batch_seed42_v100"
SEED = 42


CONFIGURATIONS = {
    "C0": {
        "description": "hybrid self-attention head-focused gate-off backbone",
        "model_variant": "hybrid",
        "soft_gate": "off",
        "cross_stock_mode": "self_attention",
        "head_loss_weight": 1.0,
        "global_rank_weight": 0.2,
    },
    "C1": {
        "description": "complete model with soft gate",
        "model_variant": "hybrid",
        "soft_gate": "on",
        "cross_stock_mode": "self_attention",
        "head_loss_weight": 1.0,
        "global_rank_weight": 0.2,
    },
    "C2": {
        "description": "TCN-only backbone",
        "model_variant": "tcn_only",
        "soft_gate": "off",
        "cross_stock_mode": "self_attention",
        "head_loss_weight": 1.0,
        "global_rank_weight": 0.2,
    },
    "C3": {
        "description": "iTransformer-only backbone",
        "model_variant": "itransformer_only",
        "soft_gate": "off",
        "cross_stock_mode": "self_attention",
        "head_loss_weight": 1.0,
        "global_rank_weight": 0.2,
    },
    "C4": {
        "description": "parameter-matched stockwise FFN without cross-stock communication",
        "model_variant": "hybrid",
        "soft_gate": "off",
        "cross_stock_mode": "stockwise_ffn",
        "head_loss_weight": 1.0,
        "global_rank_weight": 0.2,
    },
    "C5": {
        "description": "global pairwise ranking control without head-focused term",
        "model_variant": "hybrid",
        "soft_gate": "off",
        "cross_stock_mode": "self_attention",
        "head_loss_weight": 0.0,
        "global_rank_weight": 1.0,
    },
}


def load_base_runner():
    spec = importlib.util.spec_from_file_location("frozen_monthly_runner", BASE_RUNNER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load frozen runner: {BASE_RUNNER}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def environment_snapshot() -> dict:
    snapshot = {
        "python": sys.version,
        "executable": sys.executable,
        "platform": platform.platform(),
    }
    try:
        import torch

        snapshot.update({
            "torch": torch.__version__,
            "torch_cuda": torch.version.cuda,
            "cuda_available": torch.cuda.is_available(),
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        })
    except Exception as exc:  # recorded for a useful preflight failure
        snapshot["torch_error"] = repr(exc)
    return snapshot


def build_command(run_dir: Path, fold: dict, data_file: Path, cfg: dict) -> list[str]:
    return [
        sys.executable,
        "-u",
        str(TRAIN_SCRIPT),
        "--seed",
        str(SEED),
        "--output-dir",
        str(run_dir),
        "--data-file",
        str(data_file),
        "--model-variant",
        cfg["model_variant"],
        "--cross-stock-mode",
        cfg["cross_stock_mode"],
        "--feature-num",
        "baseline24_market4",
        "--soft-gate",
        cfg["soft_gate"],
        "--ranking-loss-type",
        "head_focused",
        "--head-loss-weight",
        str(cfg["head_loss_weight"]),
        "--global-rank-weight",
        str(cfg["global_rank_weight"]),
        "--stability-weight",
        "0.05",
        "--sampling-strategy",
        "natural",
        "--training-protocol",
        "rolling_validation",
        "--refit-after-validation",
        "--data-lookback-years",
        "0",
        "--split-start-date",
        fold["candidate"]["start"],
        "--window-end-date",
        fold["test"]["end"],
        "--train-days",
        str(fold["train"]["n_days"]),
        "--gap-days",
        "5",
        "--val-days",
        str(fold["validation"]["n_days"]),
        "--gap2-days",
        "5",
        "--test-days",
        str(fold["test"]["n_days"]),
    ]


def next_attempt_dir(base: Path) -> Path:
    if not base.exists():
        return base
    index = 1
    while Path(f"{base}_retry_{index}").exists():
        index += 1
    return Path(f"{base}_retry_{index}")


def write_json_atomic(path: Path, payload: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    os.replace(temporary, path)


def completed_record(manifest: dict, config_id: str, month: str) -> dict | None:
    for record in reversed(manifest.get("runs", [])):
        if (
            record.get("config_id") == config_id
            and record.get("test_month") == month
            and record.get("seed") == SEED
            and record.get("status") == "completed"
        ):
            return record
    return None


def make_manifest(base, protocol_file: Path, data_file: Path, selected: list[str]) -> dict:
    source_files = [TRAIN_SCRIPT, MODEL_SCRIPT, CONFIG_SCRIPT, PREDICT_SCRIPT, SCORER]
    return {
        "status": "planned",
        "seed": SEED,
        "multi_seed_stability_test": False,
        "protocol": str(protocol_file),
        "protocol_sha256": base.sha256_file(protocol_file),
        "data": str(data_file),
        "data_sha256": base.sha256_file(data_file),
        "source_files": {
            str(path.relative_to(ROOT)).replace("\\", "/"): base.sha256_file(path)
            for path in source_files
        },
        "environment": environment_snapshot(),
        "configurations": {key: CONFIGURATIONS[key] for key in selected},
        "folds": [],
        "runs": [],
        "rows": [],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol-file", default=str(PROTOCOL_PATH))
    parser.add_argument("--data-file", default=str(DATA_PATH))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--config", action="append", choices=sorted(CONFIGURATIONS))
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    base = load_base_runner()
    protocol_file = Path(args.protocol_file).resolve()
    data_file = Path(args.data_file).resolve()
    protocol, folds = base.load_protocol(protocol_file, data_file)
    if protocol.get("seeds") != [SEED]:
        raise RuntimeError(f"protocol seed must be exactly [{SEED}]")
    selected = args.config or list(CONFIGURATIONS)
    commands = [
        {
            "config_id": config_id,
            "test_month": fold["test_month"],
            "command": build_command(
                Path(args.output_root).resolve()
                / config_id
                / f"month_{fold['test_month']}"
                / f"seed_{SEED}",
                fold,
                data_file,
                CONFIGURATIONS[config_id],
            ),
        }
        for config_id in selected
        for fold in folds
    ]
    if not args.execute:
        print(json.dumps({"seed": SEED, "commands": commands}, ensure_ascii=False, indent=2))
        print("未指定 --execute：只完成协议校验和命令生成。", flush=True)
        return 0

    output_root = Path(args.output_root).resolve()
    manifest_path = output_root / "batch_manifest.json"
    if output_root.exists() and not args.resume:
        raise FileExistsError(f"output exists; use --resume: {output_root}")
    output_root.mkdir(parents=True, exist_ok=True)
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        expected = make_manifest(base, protocol_file, data_file, selected)
        for key in ("seed", "protocol_sha256", "data_sha256", "source_files", "configurations"):
            if manifest.get(key) != expected.get(key):
                raise RuntimeError(f"resume contract mismatch: {key}")
    else:
        manifest = make_manifest(base, protocol_file, data_file, selected)
        manifest["folds"] = folds
    manifest["status"] = "running"
    write_json_atomic(manifest_path, manifest)
    signal_dates = base.load_signal_dates(data_file)

    for config_id in selected:
        cfg = CONFIGURATIONS[config_id]
        for fold in folds:
            month = fold["test_month"]
            previous = completed_record(manifest, config_id, month)
            if previous is not None:
                base._read_evaluation(Path(previous["run_dir"]), fold, signal_dates)
                continue
            canonical = output_root / config_id / f"month_{month}" / f"seed_{SEED}"
            run_dir = next_attempt_dir(canonical)
            run_dir.mkdir(parents=True)
            command = build_command(run_dir, fold, data_file, cfg)
            log_path = run_dir / "training.log"
            record = {
                "config_id": config_id,
                "description": cfg["description"],
                "test_month": month,
                "seed": SEED,
                "run_dir": str(run_dir),
                "log": str(log_path),
                "command": command,
                "status": "running",
            }
            manifest["runs"].append(record)
            write_json_atomic(manifest_path, manifest)
            with log_path.open("w", encoding="utf-8") as log:
                completed = subprocess.run(
                    command,
                    cwd=str(TRAIN_SCRIPT.parent),
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    text=True,
                )
            record["return_code"] = completed.returncode
            if completed.returncode:
                record["status"] = "failed"
                manifest["status"] = "failed"
                write_json_atomic(manifest_path, manifest)
                return completed.returncode
            evaluation = base._read_evaluation(run_dir, fold, signal_dates)
            record["status"] = "completed"
            manifest["rows"].append({
                "model_name": config_id,
                "config_id": config_id,
                "test_month": month,
                "seed": SEED,
                "run_dir": str(run_dir),
                "test_start": fold["test"]["start"],
                "test_end": fold["test"]["end"],
                "test_evaluation_start": evaluation["evaluated_test_start"],
                "test_evaluation_end": evaluation["evaluated_test_end"],
                "test_evaluation_days": evaluation["evaluated_test_days"],
                "best_epoch": evaluation.get("best_epoch"),
                "metrics": evaluation.get("metrics", {}),
            })
            write_json_atomic(manifest_path, manifest)

    summaries = {}
    for config_id in selected:
        rows = [row for row in manifest["rows"] if row["config_id"] == config_id]
        if len(rows) != len(folds):
            raise RuntimeError(f"incomplete configuration: {config_id}")
        summaries[config_id] = base._metric_summary(rows)
        base._write_monthly_results(output_root / f"monthly_results_{config_id}.csv", rows)
    comparisons = {
        "gate_C1_minus_C0": ["C1", "C0"],
        "iTransformer_C0_minus_C2": ["C0", "C2"],
        "TCN_C0_minus_C3": ["C0", "C3"],
        "cross_stock_C0_minus_C4": ["C0", "C4"],
        "head_focus_C0_minus_C5": ["C0", "C5"],
    }
    deltas = {}
    for name, (left, right) in comparisons.items():
        if left in summaries and right in summaries:
            left_value = summaries[left]["metrics"]["top5_return"]["eligible_day_weighted_mean"]
            right_value = summaries[right]["metrics"]["top5_return"]["eligible_day_weighted_mean"]
            deltas[name] = left_value - right_value
    final_summary = {
        "seed": SEED,
        "stability_testing": False,
        "config_summaries": summaries,
        "top5_return_descriptive_deltas": deltas,
    }
    write_json_atomic(output_root / "summary.json", final_summary)
    manifest["summary"] = final_summary
    manifest["status"] = "completed"
    write_json_atomic(manifest_path, manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
