# Seed-42 V100 Ablation Reproduction Package

This archive reproduces the frozen six-configuration ablation suite for the
CSI300 future-five-day Top-5 ranking experiment. It contains code and protocol
files only. The dataset is distributed as a separate archive.

## Fixed scope

- Hardware target: one NVIDIA Tesla V100 32 GB
- Random seed: 42 only
- Configurations: C0-C5
- Evaluation windows: five frozen monthly walk-forward windows
- Total runs: 30
- No multi-seed or statistical stability test

## Environment

Python 3.11 and PyTorch 2.2.1+cu121 are the frozen reference environment.
Install the remaining dependencies with:

```bash
python -m pip install -r codex/ablation_study_seed42_v100_20260909/requirements-nontorch.txt
```

TA-Lib must also be available. If the wheel is unavailable, install the
platform TA-Lib package before running the suite.

## Dataset placement

Extract the separate dataset archive into the repository root. The expected
file is:

```text
dataset/model_data.csv
```

The runner accepts an explicit dataset path, so a mounted dataset can remain
outside the code directory.

## Verify and run

From this package root:

```bash
python codex/ablation_study_seed42_v100_20260909/test_ablation_seed42.py
python codex/ablation_study_seed42_v100_20260909/run_ablation_seed42.py \
  --data-file /mounted/dataset/model_data.csv \
  --protocol-file codex_generated/plans/monthly_walk_forward_202603_202607_week_owned_labelhorizon_repaired_20260809.json \
  --output-root runs/batch_seed42_v100 \
  --execute
```

Use `--resume` only to continue an interrupted suite. See `PLAN.md` and
`REMOTE_RUNBOOK.md` for the frozen design and operational notes.

