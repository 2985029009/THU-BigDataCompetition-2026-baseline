"""Run the frozen five-month outer walk-forward protocol.

The planner is deliberately separate from model code.  By default this file
only validates the protocol and prints the commands; training requires the
explicit ``--execute`` flag.  Every model/seed therefore receives the same
fold dates, feature contract, scorer contract, and random seed.
"""

from __future__ import annotations

import argparse
import calendar
import csv
from datetime import date
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from typing import Iterable


ROOT = Path(__file__).resolve().parents[3]
TRAIN_SCRIPT = ROOT / "code" / "src" / "train.py"
PROTOCOL_PATH = (
    ROOT / "codex_generated" / "plans"
    / "monthly_walk_forward_202603_202607.json"
)
DEFAULT_DATA = (
    ROOT / "codex_generated" / "datasets"
    / "tushare_hs300_continuous_20230724_20260731" / "model_data.csv"
)
DEFAULT_OUTPUT_ROOT = ROOT / "model" / "runs" / "monthly_walk_forward_202603_202607"
LABEL_HORIZON_DAYS = 5
INNER_GAP_DAYS = 5
OUTER_GAP_DAYS = 5
TEST_MONTHS = ((2026, 3), (2026, 4), (2026, 5), (2026, 6), (2026, 7))
METRIC_DATA_SOURCE = "predict.py_complete_candidate_universe"

FORBIDDEN_EXTRA_FLAGS = {
    "--seed",
    "--output-dir",
    "--data-file",
    "--split-start-date",
    "--window-end-date",
    "--train-days",
    "--gap-days",
    "--gap2-days",
    "--val-days",
    "--test-days",
    "--data-lookback-years",
    "--refit-after-validation",
    "--fixed-refit",
    "--feature-num",
    "--feature-transform",
    "--include-features",
    "--exclude-features",
    "--sampling-strategy",
    "--training-protocol",
    "--soft-gate",
    "--competition-train-days",
    "--competition-train-end-date",
    "--model-selection-metric",
    "--model-variant",
}
MODEL_SPECIFIC_FLAGS = {
    "--num-epochs",
    "--scheduler-total-epochs",
    "--early-stopping-patience",
    "--learning-rate",
    "--tcn-num-layers",
    "--tcn-channels",
    "--it-num-layers",
    "--ranking-loss-type",
    "--listwise-target-type",
    "--listwise-temperature",
    "--auxiliary-loss-weight",
    "--global-rank-weight",
    "--stability-weight",
    "--shortcut-correlation-weight",
    "--cross-stock-mode",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_bool(value: object) -> bool:
    return str(value).strip().lower() in {"true", "1"}


def load_signal_dates(data_file: Path) -> list[date]:
    """Match train.py's PIT split source without importing the GPU trainer."""
    dates: set[date] = set()
    with data_file.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {"日期", "is_member", "in_signal_range"}
        missing = required.difference(reader.fieldnames or ())
        if missing:
            raise ValueError(f"数据缺少切分字段: {sorted(missing)}")
        for row in reader:
            if parse_bool(row["is_member"]) and parse_bool(row["in_signal_range"]):
                dates.add(date.fromisoformat(row["日期"][:10]))
    if not dates:
        raise ValueError("PIT切分源没有可用交易日")
    return sorted(dates)


def shift_months(value: date, months: int) -> date:
    """Calendar-month arithmetic used only to define the two-year/two-month rules."""
    month_index = value.year * 12 + value.month - 1 + months
    year, month_zero = divmod(month_index, 12)
    month = month_zero + 1
    day = min(value.day, calendar.monthrange(year, month)[1])
    return date(year, month, day)


def _dates_for_month(dates: Iterable[date], year: int, month: int) -> list[date]:
    return [item for item in dates if item.year == year and item.month == month]


def _week_owner_month(item: date, week_dates: list[date]) -> tuple[int, int]:
    """Assign a Monday--Friday week by the user's three-day majority rule."""
    week_start = item.fromordinal(item.toordinal() - item.weekday())
    first_month_days = sum(
        date_item.year == week_start.year and date_item.month == week_start.month
        for date_item in week_dates
    )
    if first_month_days >= 3:
        return week_start.year, week_start.month
    following_month = shift_months(week_start, 1)
    return following_month.year, following_month.month


def _dates_for_week_owner(
    dates: Iterable[date], year: int, month: int
) -> list[date]:
    weeks: dict[date, list[date]] = {}
    for item in dates:
        week_start = item.fromordinal(item.toordinal() - item.weekday())
        weeks.setdefault(week_start, []).append(item)
    assigned = []
    for week_dates in weeks.values():
        owner_year, owner_month = _week_owner_month(week_dates[0], week_dates)
        if (owner_year, owner_month) == (year, month):
            assigned.extend(week_dates)
    return sorted(assigned)


def _eligible_test_dates(dates: list[date], test_dates: list[date]) -> list[date]:
    position = {item: index for index, item in enumerate(dates)}
    return [
        item for item in test_dates
        if len(dates) - position[item] - 1 >= LABEL_HORIZON_DAYS
    ]


def build_folds(
    dates: list[date], test_window_assignment: str = "calendar_month"
) -> list[dict]:
    """Build five disjoint outer folds from actual PIT trading dates."""
    if test_window_assignment not in {
        "calendar_month", "natural_week_majority_month",
    }:
        raise ValueError(
            f"Unknown test window assignment: {test_window_assignment}"
        )
    folds = []
    for fold, (year, month) in enumerate(TEST_MONTHS, start=1):
        test_dates = (
            _dates_for_month(dates, year, month)
            if test_window_assignment == "calendar_month"
            else _dates_for_week_owner(dates, year, month)
        )
        if not test_dates:
            raise ValueError(f"测试月没有交易日: {year:04d}-{month:02d}")

        candidate_boundary = shift_months(test_dates[0], -24)
        candidate_dates = [
            item for item in dates
            if candidate_boundary <= item < test_dates[0]
        ]
        if len(candidate_dates) <= INNER_GAP_DAYS + OUTER_GAP_DAYS:
            raise ValueError(f"候选集不足以切出隔离和验证: {year:04d}-{month:02d}")

        outer_gap_dates = candidate_dates[-OUTER_GAP_DAYS:]
        eligible_candidate = candidate_dates[:-OUTER_GAP_DAYS]
        validation_boundary = shift_months(outer_gap_dates[0], -2)
        validation_dates = [
            item for item in eligible_candidate if item >= validation_boundary
        ]
        pre_validation = [
            item for item in candidate_dates if item < validation_dates[0]
        ]
        if len(pre_validation) <= INNER_GAP_DAYS:
            raise ValueError(f"训练段不足以切出内部隔离: {year:04d}-{month:02d}")
        inner_gap_dates = pre_validation[-INNER_GAP_DAYS:]
        train_dates = pre_validation[:-INNER_GAP_DAYS]
        if not train_dates or not validation_dates:
            raise ValueError(f"训练/验证段为空: {year:04d}-{month:02d}")

        eligible_test = _eligible_test_dates(dates, test_dates)
        folds.append({
            "fold": fold,
            "test_month": f"{year:04d}-{month:02d}",
            "candidate": {
                "start": candidate_dates[0].isoformat(),
                "end": candidate_dates[-1].isoformat(),
                "n_days": len(candidate_dates),
            },
            "train": {
                "start": train_dates[0].isoformat(),
                "end": train_dates[-1].isoformat(),
                "n_days": len(train_dates),
            },
            "gap1": {
                "start": inner_gap_dates[0].isoformat(),
                "end": inner_gap_dates[-1].isoformat(),
                "n_days": len(inner_gap_dates),
                "role": "label_embargo_before_validation",
            },
            "validation": {
                "start": validation_dates[0].isoformat(),
                "end": validation_dates[-1].isoformat(),
                "n_days": len(validation_dates),
            },
            "gap2": {
                "start": outer_gap_dates[0].isoformat(),
                "end": outer_gap_dates[-1].isoformat(),
                "n_days": len(outer_gap_dates),
                "role": "label_embargo_before_outer_test",
            },
            "test": {
                "start": test_dates[0].isoformat(),
                "end": test_dates[-1].isoformat(),
                "n_days": len(test_dates),
            },
            "test_evaluation": {
                "start": eligible_test[0].isoformat() if eligible_test else None,
                "end": eligible_test[-1].isoformat() if eligible_test else None,
                "n_days": len(eligible_test),
                "label_horizon": LABEL_HORIZON_DAYS,
                "reason_if_shorter": (
                    "末尾测试目标的5日标签超出数据文件可见范围"
                    if len(eligible_test) != len(test_dates) else None
                ),
            },
            "refit": {
                "start": train_dates[0].isoformat(),
                "end": validation_dates[-1].isoformat(),
                "n_days": len(train_dates) + len(validation_dates),
                "excluded_gap1_days": len(inner_gap_dates),
            },
        })
    return folds


def load_protocol(protocol_path: Path, data_file: Path) -> tuple[dict, list[dict]]:
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    # A repaired data batch is a new frozen protocol, but it inherits the
    # already-frozen shared dates/features/scorer from the parent protocol.
    # Pinning the parent hash prevents an implicit change to that common
    # environment while avoiding a second, manually copied 5-fold definition.
    parent = protocol.get("base_protocol")
    if parent:
        parent_path = ROOT / parent["file"]
        actual_parent_sha256 = sha256_file(parent_path)
        if actual_parent_sha256.lower() != parent["sha256"].lower():
            raise ValueError(
                "Inherited frozen protocol SHA256 mismatch: "
                f"expected={parent['sha256']}, actual={actual_parent_sha256}"
            )
        inherited = json.loads(parent_path.read_text(encoding="utf-8"))
        if "data" not in protocol:
            raise ValueError("Derived protocol must explicitly pin its data batch")
        inherited["protocol_version"] = protocol["protocol_version"]
        inherited["status"] = protocol["status"]
        inherited["purpose"] = protocol["purpose"]
        inherited["data"] = protocol["data"]
        # Derived protocols may deliberately replace the outer-test ownership
        # rule and its resulting frozen folds, while retaining every other
        # common environment field from the parent.
        for key in ("outer_test", "folds"):
            if key in protocol:
                inherited[key] = protocol[key]
        inherited["derived_protocol"] = {
            "path": str(protocol_path.relative_to(ROOT)).replace("\\", "/"),
            "sha256": sha256_file(protocol_path),
            "base_protocol": parent,
            "data_repair": protocol.get("data_repair"),
            "change_scope": protocol.get("change_scope"),
            "test_window_assignment": protocol.get("outer_test", {}).get(
                "test_window_assignment"
            ),
        }
        protocol = inherited
    common_environment = protocol["common_model_environment"]
    if protocol["seeds"] != common_environment["seeds"]:
        raise ValueError("顶层seed集合与公共模型环境seed集合不一致")
    actual_sha256 = sha256_file(data_file)
    expected_sha256 = protocol["data"]["sha256"]
    if actual_sha256.lower() != expected_sha256.lower():
        raise ValueError(
            "数据SHA256与冻结协议不一致: "
            f"expected={expected_sha256}, actual={actual_sha256}"
        )
    scorer_path = ROOT / common_environment["official_scorer"]
    actual_scorer_sha256 = sha256_file(scorer_path)
    expected_scorer_sha256 = common_environment["scorer_sha256"]
    if actual_scorer_sha256.lower() != expected_scorer_sha256.lower():
        raise ValueError(
            "评分器SHA256与冻结协议不一致: "
            f"expected={expected_scorer_sha256}, actual={actual_scorer_sha256}"
        )
    folds = build_folds(
        load_signal_dates(data_file),
        protocol.get("outer_test", {}).get(
            "test_window_assignment", "calendar_month"
        ),
    )
    if folds != protocol["folds"]:
        raise ValueError("当前交易日历推导的折叠与冻结协议不一致")
    return protocol, folds


def build_command(
    run_dir: Path,
    seed: int,
    fold: dict,
    data_file: Path,
    model_variant: str,
    extra_args: list[str],
) -> list[str]:
    command = [
        sys.executable, "-u", str(TRAIN_SCRIPT),
        "--seed", str(seed), "--output-dir", str(run_dir),
        "--data-file", str(data_file), "--model-variant", model_variant,
        "--feature-num", "baseline24_market4", "--soft-gate", "on",
        "--sampling-strategy", "natural", "--training-protocol",
        "rolling_validation", "--refit-after-validation",
        "--data-lookback-years", "0",
        "--split-start-date", fold["candidate"]["start"],
        "--window-end-date", fold["test"]["end"],
        "--train-days", str(fold["train"]["n_days"]),
        "--gap-days", str(INNER_GAP_DAYS),
        "--val-days", str(fold["validation"]["n_days"]),
        "--gap2-days", str(OUTER_GAP_DAYS),
        "--test-days", str(fold["test"]["n_days"]),
    ]
    for token in extra_args:
        flag = token.split("=", 1)[0]
        if flag in FORBIDDEN_EXTRA_FLAGS:
            raise ValueError(f"模型参数不得覆盖公共协议参数: {flag}")
        if flag not in MODEL_SPECIFIC_FLAGS:
            raise ValueError(f"未知或不允许的模型参数: {flag}")
    return command + list(extra_args)


def _assert_runtime_split(actual: dict, expected: dict) -> None:
    for key in ("train", "gap1", "validation", "gap2", "test"):
        for field in ("start", "end", "n_days"):
            if actual.get(key, {}).get(field) != expected[key].get(field):
                raise RuntimeError(
                    f"训练器实际{key}.{field}与公共协议不一致: "
                    f"{actual.get(key, {}).get(field)} != {expected[key].get(field)}"
                )


def _read_evaluation(
    run_dir: Path, fold: dict, signal_dates: list[date]
) -> dict:
    split = json.loads((run_dir / "data_split.json").read_text(encoding="utf-8"))
    _assert_runtime_split(split, fold)
    evaluation = json.loads(
        (run_dir / "evaluation_test.json").read_text(encoding="utf-8")
    )
    if evaluation.get("protocol") != "held_out_test_after_full_train_refit":
        raise RuntimeError("测试评估没有使用验证后完整重训协议")
    if not evaluation.get("refit_performed"):
        raise RuntimeError("训练器未执行 train+validation refit")
    if evaluation.get("metric_data_source") != METRIC_DATA_SOURCE:
        raise RuntimeError(
            "测试指标未基于predict.py完整候选池计算: "
            f"{evaluation.get('metric_data_source')}"
        )
    ranking_name = evaluation.get("full_ranking_file")
    universe_name = evaluation.get("universe_audit_file")
    if ranking_name != "evaluation_test_full_ranking.csv" or not universe_name:
        raise RuntimeError("测试评估缺少完整raw_score或候选池审计文件声明")
    ranking_path = run_dir / ranking_name
    universe_path = run_dir / universe_name
    if not ranking_path.is_file() or not universe_path.is_file():
        raise RuntimeError("测试评估缺少完整raw_score或候选池审计文件")
    for field in ("test_start", "test_end"):
        expected = fold["test"]["start" if field == "test_start" else "end"]
        if evaluation.get(field) != expected:
            raise RuntimeError(
                f"测试评估{field}与公共协议不一致: "
                f"{evaluation.get(field)} != {expected}"
            )
    for field, expected in (
        ("evaluated_test_start", fold["test_evaluation"]["start"]),
        ("evaluated_test_end", fold["test_evaluation"]["end"]),
        ("evaluated_test_days", fold["test_evaluation"]["n_days"]),
        (
            "refit_train_target_days",
            fold["train"]["n_days"] + fold["validation"]["n_days"],
        ),
    ):
        if evaluation.get(field) != expected:
            raise RuntimeError(
                f"测试评估{field}与公共协议不一致: "
                f"{evaluation.get(field)} != {expected}"
            )
    metric_days = evaluation.get("metrics", {}).get("_n_days")
    if metric_days != fold["test_evaluation"]["n_days"]:
        raise RuntimeError(
            "测试指标有效日数与公共协议不一致: "
            f"{metric_days} != {fold['test_evaluation']['n_days']}"
        )
    expected_refit_dates = [
        item.isoformat() for item in signal_dates
        if (
            fold["train"]["start"] <= item.isoformat() <= fold["train"]["end"]
            or fold["validation"]["start"]
            <= item.isoformat()
            <= fold["validation"]["end"]
        )
    ]
    refit_dates_path = run_dir / "refit_target_dates.json"
    refit_dates_payload = json.loads(refit_dates_path.read_text(encoding="utf-8"))
    if refit_dates_payload.get("dates") != expected_refit_dates:
        raise RuntimeError("refit目标日期集合与公共协议不一致")
    expected_test_dates = _eligible_test_dates(
        signal_dates,
        [
            item for item in signal_dates
            if fold["test"]["start"] <= item.isoformat() <= fold["test"]["end"]
        ],
    )
    if evaluation.get("evaluated_test_dates") != [
        item.isoformat() for item in expected_test_dates
    ]:
        raise RuntimeError("实际测试评估日期集合与公共协议不一致")
    universe_payload = json.loads(universe_path.read_text(encoding="utf-8"))
    if universe_payload.get("data_source") != METRIC_DATA_SOURCE:
        raise RuntimeError("候选池审计文件的数据来源不正确")
    universe_by_date = {
        item.get("signal_date"): item for item in universe_payload.get("days", [])
    }
    expected_date_strings = [item.isoformat() for item in expected_test_dates]
    if set(universe_by_date) != set(expected_date_strings):
        raise RuntimeError("候选池审计日期与实际测试评估日期不一致")
    with ranking_path.open("r", encoding="utf-8-sig", newline="") as handle:
        ranking_rows = list(csv.DictReader(handle))
    required_columns = {
        "signal_date", "stock_id", "raw_score", "raw_rank",
        "future_return", "selected_top5", "weight",
    }
    if not ranking_rows or not required_columns.issubset(ranking_rows[0]):
        raise RuntimeError("完整预测排序文件缺少必要字段")
    ranking_by_date: dict[str, list[dict]] = {}
    for row in ranking_rows:
        ranking_by_date.setdefault(row["signal_date"], []).append(row)
    if set(ranking_by_date) != set(expected_date_strings):
        raise RuntimeError("完整预测排序日期与实际测试评估日期不一致")
    for signal_date, rows in ranking_by_date.items():
        expected_count = universe_by_date[signal_date].get("scored_stocks")
        actual_ranks = sorted(int(row["raw_rank"]) for row in rows)
        if len(rows) != expected_count or actual_ranks != list(
            range(1, len(rows) + 1)
        ):
            raise RuntimeError(
                f"完整预测排序在{signal_date}未覆盖候选池或rank不连续"
            )
    return evaluation


def _metric_summary(rows: list[dict]) -> dict:
    metric_names = sorted({
        key for row in rows for key in row["metrics"]
        if not key.startswith("_")
        and isinstance(row["metrics"].get(key), (int, float))
    })
    total_days = sum(row["test_evaluation_days"] for row in rows)
    output = {
        "n_months": len({row["test_month"] for row in rows}),
        "n_rows": len(rows),
        "aggregation": "eligible_test_day_weighted_mean",
        "eligible_test_days": total_days,
        "metrics": {},
    }
    for metric in metric_names:
        values = [
            (float(row["metrics"][metric]), row["test_evaluation_days"])
            for row in rows if metric in row["metrics"]
        ]
        denominator = sum(days for _, days in values)
        output["metrics"][metric] = {
            "eligible_day_weighted_mean": (
                sum(value * days for value, days in values) / denominator
                if denominator else None
            ),
            "equal_month_mean": (
                sum(value for value, _ in values) / len(values) if values else None
            ),
        }
    return output


def _write_monthly_results(path: Path, rows: list[dict]) -> None:
    fieldnames = [
        "model_name", "test_month", "seed", "test_start", "test_end",
        "test_evaluation_start", "test_evaluation_end",
        "test_evaluation_days", "best_epoch",
    ]
    metric_names = sorted({
        key for row in rows for key in row["metrics"]
        if not key.startswith("_")
    })
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames + metric_names)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                **{key: row.get(key) for key in fieldnames},
                **{key: row["metrics"].get(key) for key in metric_names},
            })


def run(protocol: dict, folds: list[dict], args: argparse.Namespace) -> int:
    output_root = Path(args.output_root).resolve()
    if output_root.exists():
        raise FileExistsError(f"输出目录已存在，拒绝覆盖: {output_root}")
    output_root.mkdir(parents=True)
    signal_dates = load_signal_dates(Path(args.data_file))
    manifest = {
        "status": "running",
        "protocol": str(Path(args.protocol_file).resolve()),
        "protocol_sha256": sha256_file(Path(args.protocol_file).resolve()),
        "model_name": args.model_name,
        "model_variant": args.model_variant,
        "seeds": list(protocol["seeds"]),
        "dataset": protocol["data"],
        "trainer": {
            "path": str(TRAIN_SCRIPT),
            "sha256": sha256_file(TRAIN_SCRIPT),
        },
        "train_extra_args": list(args.train_extra_arg),
        "folds": folds,
        "runs": [],
        "rows": [],
    }
    (output_root / "batch_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    for fold in folds:
        for seed in protocol["seeds"]:
            run_dir = output_root / f"month_{fold['test_month']}" / f"seed_{seed}"
            run_dir.mkdir(parents=True)
            command = build_command(
                run_dir, seed, fold, Path(args.data_file),
                args.model_variant, args.train_extra_arg,
            )
            log_path = run_dir / "training.log"
            run_record = {
                "test_month": fold["test_month"],
                "seed": seed,
                "run_dir": str(run_dir),
                "log": str(log_path),
                "command": command,
                "status": "running",
            }
            manifest["runs"].append(run_record)
            (output_root / "batch_manifest.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            with log_path.open("w", encoding="utf-8") as log:
                completed = subprocess.run(
                    command, cwd=str(TRAIN_SCRIPT.parent),
                    stdout=log, stderr=subprocess.STDOUT, text=True,
                )
            if completed.returncode:
                run_record["status"] = "failed"
                run_record["return_code"] = completed.returncode
                manifest["status"] = "failed"
                manifest["failed_command"] = command
                manifest["return_code"] = completed.returncode
                (output_root / "batch_manifest.json").write_text(
                    json.dumps(manifest, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                return completed.returncode
            evaluation = _read_evaluation(run_dir, fold, signal_dates)
            run_record["status"] = "completed"
            run_record["return_code"] = 0
            row = {
                "model_name": args.model_name,
                "test_month": fold["test_month"],
                "seed": seed,
                "run_dir": str(run_dir),
                "test_start": fold["test"]["start"],
                "test_end": fold["test"]["end"],
                "test_evaluation_start": evaluation["evaluated_test_start"],
                "test_evaluation_end": evaluation["evaluated_test_end"],
                "test_evaluation_days": evaluation["evaluated_test_days"],
                "best_epoch": evaluation.get("best_epoch"),
                "metrics": evaluation.get("metrics", {}),
            }
            manifest["rows"].append(row)
            (output_root / "batch_manifest.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

    summary = _metric_summary(manifest["rows"])
    manifest["summary"] = summary
    manifest["status"] = "completed"
    (output_root / "batch_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output_root / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    _write_monthly_results(output_root / "monthly_results.csv", manifest["rows"])
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--model-name", default="current_model")
    parser.add_argument(
        "--model-variant", choices=["hybrid", "tcn_only", "itransformer_only"],
        default="hybrid",
    )
    parser.add_argument("--data-file", default=str(DEFAULT_DATA))
    parser.add_argument(
        "--protocol-file", default=str(PROTOCOL_PATH),
        help="Frozen protocol JSON; a derived protocol may pin a new data batch while inheriting the original common environment.",
    )
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument(
        "--test-month", choices=[f"{year:04d}-{month:02d}" for year, month in TEST_MONTHS],
        help="只运行指定的外层测试月；用于单窗口训练验证",
    )
    parser.add_argument(
        "--train-extra-arg", action="append", default=[],
        help="模型专属参数；不得覆盖公共切分、特征、数据、种子或refit参数",
    )
    parser.add_argument(
        "--execute", action="store_true",
        help="显式启动训练；未指定时只做协议校验并打印命令",
    )
    args = parser.parse_args()
    data_file = Path(args.data_file).resolve()
    args.protocol_file = str(Path(args.protocol_file).resolve())
    protocol, folds = load_protocol(Path(args.protocol_file), data_file)
    if args.test_month:
        folds = [fold for fold in folds if fold["test_month"] == args.test_month]
    for extra in args.train_extra_arg:
        flag = extra.split("=", 1)[0]
        if flag in FORBIDDEN_EXTRA_FLAGS:
            raise ValueError(f"模型参数不得覆盖公共协议参数: {flag}")
    commands = [
        build_command(
            Path(args.output_root).resolve() / f"month_{fold['test_month']}"
            / f"seed_{seed}", seed, fold, data_file,
            args.model_variant, args.train_extra_arg,
        )
        for fold in folds for seed in protocol["seeds"]
    ]
    if not args.execute:
        print(json.dumps({"protocol": protocol, "folds": folds, "commands": commands},
                         ensure_ascii=False, indent=2))
        print("未指定 --execute：仅完成协议校验，未启动训练。", flush=True)
        return 0
    return run(protocol, folds, args)


if __name__ == "__main__":
    raise SystemExit(main())
